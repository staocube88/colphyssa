<?php
if( !class_exists('adifier_elementor_kc_categories_list') ){
class Adifier_Elementor_kc_categories_list extends Adifier_Elementor_Base {

}
}
?>