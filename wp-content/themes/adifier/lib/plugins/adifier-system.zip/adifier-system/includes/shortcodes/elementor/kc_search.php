<?php
if( !class_exists('Adifier_Elementor_kc_search') ){
class Adifier_Elementor_kc_search extends Adifier_Elementor_Base {

}
}
?>