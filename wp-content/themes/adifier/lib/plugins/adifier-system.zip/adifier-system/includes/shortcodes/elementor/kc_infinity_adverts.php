<?php
if( !class_exists('Adifier_Elementor_kc_infinity_adverts') ){
class Adifier_Elementor_kc_infinity_adverts extends Adifier_Elementor_Base {

}
}
?>