<?php
if( !class_exists('Adifier_Elementor_kc_af_locations_list') ){
class Adifier_Elementor_kc_af_locations_list extends Adifier_Elementor_Base {

}
}
?>