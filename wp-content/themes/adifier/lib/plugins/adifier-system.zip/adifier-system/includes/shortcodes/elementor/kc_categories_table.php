<?php
if( !class_exists('Adifier_Elementor_kc_categories_table') ){
class Adifier_Elementor_kc_categories_table extends Adifier_Elementor_Base {

}
}
?>